package com.fdmgroup.repository;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.fdmgroup.model.Product;

@Repository
public class ProductRepo {
Map<Integer,Product> products = new HashMap<>();

public String saveData(Product product)
{
	products.put(product.getId(), product);
	return "saving in repo";
	}
}
