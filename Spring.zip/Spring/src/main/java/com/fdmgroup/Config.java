package com.fdmgroup;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fdmgroup.model.Product;

@Configuration
@ComponentScan("com.fdmgroup")
public class Config {

	@Bean
	@Scope("prototype")
	public Product product(int id,String name, double price)
	{
		return new Product(id,name,price);
		
	}
	
}
