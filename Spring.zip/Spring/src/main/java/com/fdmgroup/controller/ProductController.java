package com.fdmgroup.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.fdmgroup.model.Product;
import com.fdmgroup.service.ProductService;

@Controller
public class ProductController {
private ProductService prodservice;

@Autowired
public ProductController(ProductService prodservice) {
	super();
	this.prodservice = prodservice;
}

public String saveToRepo(Product product)
{
	return prodservice.saveToRepo(product);
	}
}
