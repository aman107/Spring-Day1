package com.fdmgroup.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fdmgroup.model.Product;
import com.fdmgroup.repository.ProductRepo;

@Service
public class ProductService {

	private ProductRepo ProdRepo;
	
@Autowired

public ProductService(ProductRepo ProdRepo)
{
	super();
	this.ProdRepo = ProdRepo;
	}
	public String saveToRepo(Product product)
	{
		return ProdRepo.saveData(product);
		
	}
}
