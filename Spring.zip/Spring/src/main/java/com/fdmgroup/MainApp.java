package com.fdmgroup;

import java.util.Scanner;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.fdmgroup.controller.ProductController;
import com.fdmgroup.model.Product;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(Config.class);
		ProductController cn = ctx.getBean(ProductController.class);
		
		
		System.out.println("Enter product details");
		Scanner sc  = new Scanner(System.in);
		int id = sc.nextInt();
		String name = sc.next();
		double price = sc.nextDouble();
		Product p1 = (Product) ctx.getBean("product",id, name, price);
		System.out.println(cn.saveToRepo(p1));
	}

}
